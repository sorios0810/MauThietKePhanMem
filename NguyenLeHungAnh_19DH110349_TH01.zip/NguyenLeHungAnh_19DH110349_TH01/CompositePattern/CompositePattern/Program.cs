﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompositePattern
{
    interface IEmployee
    {
        string Name { get; set; } //name
        string Dept { get; set; } //phong ban
        string Designation { get; set; } // chi dinh
        void DisplayDetails(); //hien thi chi tiet
    }
    // leaf node
    class Employee : IEmployee
    {
        public string Name { get; set; } //name
        public string Dept { get; set; } //phong ban
        public string Designation { get; set; } // chi dinh
        public void DisplayDetails() //hien thi chi tiet
        {
            Console.WriteLine("\t {0} lam viec tai phong {1}." + "Chi dinh: {2}", Name, Dept, Designation);
        }
    }
    // none leaf node
    class CompositeEmployee : IEmployee
    {
        public string Name { get; set; } //name
        public string Dept { get; set; } //phong ban
        public string Designation { get; set; } // chi dinh
        private List<IEmployee> sublist = new List<IEmployee>();
        // add an Employee
        public void AddEmployee(IEmployee e)
        {
            sublist.Add(e);
        }
        // remove an Employee
        public void RemoveEmployee(IEmployee e)
        {
            sublist.Remove(e);
        }
        public void DisplayDetails() //hien thi chi tiet
        {
            Console.WriteLine("{0} lam viec tai phong {1}." + "Chi dinh: {2}", Name, Dept, Designation);
            foreach(IEmployee e in sublist)
            {
                e.DisplayDetails();
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Demo");
            Employee Toan_1 = new Employee { Name = "Nguyen Van A", Dept = "Khoa Toan", Designation = "Giang Vien" };
            Employee Toan_2 = new Employee { Name = "Nguyen Van B", Dept = "Khoa Toan", Designation = "Tro Giang" };
            CompositeEmployee HODToan = new CompositeEmployee { Name = "Le Van C", Dept = "Khoa Toan", Designation = "Truong Khoa" };

            //2 GV khoa Toan se bao cao truc tiep cho HOD Toan
            HODToan.AddEmployee(Toan_1);
            HODToan.AddEmployee(Toan_2);

            Employee CSEE_1 = new Employee { Name = "Tran Van A", Dept = "Khoa CSE", Designation = "Giang Vien" };
            Employee CSEE_2 = new Employee { Name = "Tran Van L", Dept = "Khoa CSE", Designation = "Giang Vien" };
            Employee CSEE_3 = new Employee { Name = "Ly Hanh P", Dept = "Khoa CSE", Designation = "Giang Vien" };
            CompositeEmployee HODCSE = new CompositeEmployee { Name = "Nong Van D", Dept = "Khoa CSE", Designation = "Truong Khoa" };

            //3 GV khoa Toan se bao cao truc tiep cho HOD CSE
            HODCSE.AddEmployee(CSEE_1);
            HODCSE.AddEmployee(CSEE_2);
            HODCSE.AddEmployee(CSEE_3);

            CompositeEmployee HT = new CompositeEmployee { Name = "Mr.H", Dept = "Ke Hoach Quan Ly", Designation = "Hieu Truong" };

            //2 HOD khoa Toan se bao cao truc tiep cho HT
            HT.AddEmployee(HODToan);
            HT.AddEmployee(HODCSE);

            Console.WriteLine("Thong tin tu hieu truong: ");
            HT.DisplayDetails();
            Console.WriteLine("--------------------------");
            Console.WriteLine("Thong tin tu khoa CSE");
            HODCSE.DisplayDetails();
            Console.WriteLine("--------------------------");
            Console.WriteLine("Thong tin giang vien Toan 1");
            Toan_1.DisplayDetails();

            // GV Toan 2 nop don nghi
            Console.WriteLine("--------------------------");
            Console.WriteLine("GV {0} nop don nghi khoa {1}", CSEE_2.Name, CSEE_2.Dept);
            HODToan.RemoveEmployee(CSEE_2);
            HODCSE.DisplayDetails();

            Console.ReadKey();
        }
    }
}
