﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WMP_App
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            // lay thoing tin
            OFD.ShowDialog();
            DialogResult DR = OFD.ShowDialog();
            if(DR == DialogResult.OK)
            {
                string url = OFD.FileName;
                this.WMPDisplay.URL = url;
            }
        }
    }
}
