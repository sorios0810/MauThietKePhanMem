﻿namespace WMP_App
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.btnPlay = new System.Windows.Forms.Button();
            this.OFD = new System.Windows.Forms.OpenFileDialog();
            this.WMPDisplay = new AxWMPLib.AxWindowsMediaPlayer();
            ((System.ComponentModel.ISupportInitialize)(this.WMPDisplay)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPlay
            // 
            this.btnPlay.Location = new System.Drawing.Point(12, 12);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(109, 27);
            this.btnPlay.TabIndex = 0;
            this.btnPlay.Text = "Choose File ";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // OFD
            // 
            this.OFD.Filter = "Music|*.mp3|Movie|*.mp4|All File|*.*";
            // 
            // WMPDisplay
            // 
            this.WMPDisplay.Enabled = true;
            this.WMPDisplay.Location = new System.Drawing.Point(12, 45);
            this.WMPDisplay.Name = "WMPDisplay";
            this.WMPDisplay.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("WMPDisplay.OcxState")));
            this.WMPDisplay.Size = new System.Drawing.Size(517, 212);
            this.WMPDisplay.TabIndex = 1;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 272);
            this.Controls.Add(this.WMPDisplay);
            this.Controls.Add(this.btnPlay);
            this.Name = "MainForm";
            this.Text = "Windows Media Player App";
            ((System.ComponentModel.ISupportInitialize)(this.WMPDisplay)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.OpenFileDialog OFD;
        private AxWMPLib.AxWindowsMediaPlayer WMPDisplay;
    }
}

